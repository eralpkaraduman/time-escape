package levels 
{
	import actors.Portal;
	import actors.ProtoPlayer;
	import artifacts.artifactSparkle;
	import com.aukyr.flixel.PNGTileMap;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.geom.Point;
	import org.flixel.FlxCamera;
	import org.flixel.FlxG;
	import org.flixel.FlxGroup;
	import org.flixel.FlxObject;
	import org.flixel.FlxRect;
	import org.flixel.FlxState;
	import org.flixel.FlxTilemap;
	import org.flixel.FlxU;
	import screens.WinState;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class HQState extends FlxState 
	{
		public var player:ProtoPlayer;
		//[Embed(source = '../maps/protoMap.png')]private var protoLevelMap:Class;
		[Embed(source = '../maps/protoTiles.png')]private var protoTiles:Class;
		[Embed(source = '../maps/HQMap.png')]private var HQTiles:Class;
		public var map:FlxTilemap;
		private var playerSpawnPoint:Point;
		private var portalPoints:Array;
		private var portalsGroup:FlxGroup = new FlxGroup();
		private static var lastEnteredTo:int = -1;
		private var levelNames:Array;
		private var levelClasses:Array;
		private var rePortalTimer:Number;
		private var levelCompletion:Array;
		private var gameWon:Boolean = false;
		private var canFade:Boolean = true;
		private var gameWonTimer:Number = 0;
		
		public function HQState() 
		{
			
		}
		
		override public function create():void {
			
			FlxG.bgColor = Main.skyColor;
			FlxG.timeScale = 1;
			
			// map
			var statics:Array = PNGTileMap.parseIndexes(HQTiles, 0x000000, 1, 0);
			map = new FlxTilemap();
			map.loadMap(FlxTilemap.arrayToCSV(statics, PNGTileMap.getRect(HQTiles).width), protoTiles, 0, 0, FlxTilemap.AUTO);
			add(map);
			
			var mapScales:Point = new Point(map.width, map.height);
			
			// points
			playerSpawnPoint = PNGTileMap.parsePoints(HQTiles, 0x0000FF, mapScales)[0];
			portalPoints = PNGTileMap.parsePoints(HQTiles, 0x0094FF, mapScales);
			
			// portals
			levelNames = ["814 BC", "813 BC", "812 BC", "811 BC", "810 BC", ];
			levelClasses = [ProtoState, ProtoState, ProtoState, ProtoState, ProtoState];
			levelCompletion = [false, true, true, true, true];
			var i:int = 0;
			for each(var p:Point in portalPoints) {
				var portal:Portal = new Portal(p.x, p.y);
				var sparkle:artifactSparkle = new artifactSparkle();
				sparkle.x = p.x-2;
				sparkle.y = p.y-20;
				portal.id = i;
				i++;
				portalsGroup.add(portal);
				add(sparkle);
			}
			add(portalsGroup);
			
			// player
			var velP:Point = new Point();
			if (lastEnteredTo != -1) {
				playerSpawnPoint.x = portalPoints[lastEnteredTo].x;
				playerSpawnPoint.y = portalPoints[lastEnteredTo].y;
				velP.x = (portalPoints[lastEnteredTo].x > (map.width / 2))? -1500 : 1500;
				velP.y = -1500;
			}
			player = new ProtoPlayer(playerSpawnPoint.x, playerSpawnPoint.y);
			rePortalTimer = 0;
			player.velocity.x = velP.x;
			player.velocity.y = velP.y;
			add(player);
			
			FlxG.camera.setBounds(0, 0, map.width, map.height);
			FlxG.camera.follow(player, FlxCamera.STYLE_PLATFORMER);
			FlxG.worldBounds = new FlxRect(0, 0, map.width, map.height);
			
			// Y NO WON GAME ?
			if (ProtoState.gotArtifact) {
				trace("YESSS");
				gameWon = true;
				ProtoState.gotArtifact = false; // so you can play again
				//FlxG.fade(0xffFFFFFF, 2, onWinFadeComplete);
			}
		}
		
		public function onWinFadeComplete():void 
		{
			trace("YESSS -contd");
			FlxG.switchState(new WinState());
		}
		
		override public function update():void {
			if (gameWon) {
				gameWonTimer += FlxG.elapsed;
				if (gameWonTimer > 2) {
					if (canFade) {
						FlxG.fade(0xffFFFFFF, 1.5, onWinFadeComplete);
						canFade = false;
					}
				}
			}
			
			FlxG.collide(player, map);
			FlxG.overlap(player, portalsGroup,playerOverlapsPortal);
			
			if (player.y > map.height) {
				player.spawn(playerSpawnPoint);
			}
			
			rePortalTimer += FlxG.elapsed;
			
			super.update();
			
		}
		
		private function playerOverlapsPortal(ob1:FlxObject,ob2:Portal):void 
		{
			if (gameWon) return;
			
			if (rePortalTimer < 1) return;
			lastEnteredTo = ob2.id;
			FlxG.switchState(new levelClasses[lastEnteredTo]);
		}
		
	}

}