package levels 
{
	import actors.Artifact;
	import actors.Portal;
	import actors.ProtoEnemy;
	import actors.ProtoPlayer;
	import artifacts.artifactSparkle;
	import artifacts.ScottishClaymore;
	import com.aukyr.flixel.PNGTileMap;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.geom.Point;
	import org.flixel.FlxCamera;
	import org.flixel.FlxG;
	import org.flixel.FlxGroup;
	import org.flixel.FlxObject;
	import org.flixel.FlxRect;
	import org.flixel.FlxSprite;
	import org.flixel.FlxState;
	import org.flixel.FlxTilemap;
	import org.flixel.FlxU;
	import screens.ScreenDieHit;
	import ui.UI;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class ProtoState extends FlxState 
	{
		public var player:ProtoPlayer;
		[Embed(source = '../maps/protoMap.png')]private var protoLevelMap:Class;
		[Embed(source = '../maps/protoTiles.png')]private var protoTiles:Class;
		public var map:FlxTilemap;
		
		private var playerSpawnPoint:Point;
		private var artifactOriginalPoint:Point;
		private var artifact:Artifact;
		private var enemyPoints:Array;
		private var enemyGroup:FlxGroup;
		private var portal:Portal;
		private var rePortalTimer:Number;
		private var artifactWeapon:ScottishClaymore;
		private var canHitPlayer:Boolean = true;
		private var enemyCanHitTimer:Number = 0;
		private var ui:UI;
		
		private var dirtWall:FlxSprite;
		private var lightRay:FlxSprite;
		
		public static var gotArtifact:Boolean = false;
		
		public function ProtoState() 
		{
			
		}
		
		override public function create():void {
			
			//FlxG.bgColor = 0xff9bc7bf;
			FlxG.bgColor = Main.skyColor;
			
			//dirtwall
			dirtWall = new FlxSprite();
			add(dirtWall);
			
			//lightray
			//976d31
			lightRay = new FlxSprite();
			add(lightRay);
			
			// map
			var statics:Array = PNGTileMap.parseIndexes(protoLevelMap, 0x000000, 1,0);
			map = new FlxTilemap();
			map.loadMap(FlxTilemap.arrayToCSV(statics, PNGTileMap.getRect(protoLevelMap).width), protoTiles, 0, 0, FlxTilemap.AUTO);
			add(map);
			var mapScales:Point = new Point(map.width, map.height);
			
			//dirtwall - contd
			var dirtWallP:Point = PNGTileMap.parsePoints(protoLevelMap, 0xFF6A00, mapScales)[0];
			dirtWall.makeGraphic(map.width, map.height * 2, 0xff976d31);
			dirtWall.x = dirtWallP.x + 8;
			
			//lightray - contd
			var lightRayP:Point = PNGTileMap.parsePoints(protoLevelMap, 0xFFD800, mapScales)[0];
			lightRay.makeGraphic(8, map.height * 2, 0xfffff8af);
			lightRay.x = lightRayP.x+1;
			
			// points
			playerSpawnPoint = PNGTileMap.parsePoints(protoLevelMap, 0x0000FF, mapScales)[0];
			artifactOriginalPoint = PNGTileMap.parsePoints(protoLevelMap, 0xDC00FF, mapScales)[0];
			enemyPoints = PNGTileMap.parsePoints(protoLevelMap, 0xFF0000, mapScales);
			
			//portal
			portal = new Portal(playerSpawnPoint.x, playerSpawnPoint.y);
			add(portal);
			
			// enemies
			enemyGroup = new FlxGroup();
			for each(var p:Point in enemyPoints) {
				var e:ProtoEnemy = new ProtoEnemy(p.x,p.y);
				enemyGroup.add(e);
			}
			add(enemyGroup);
			
			// player
			player = new ProtoPlayer(playerSpawnPoint.x, playerSpawnPoint.y);
			player.velocity.y = -1500;
			player.velocity.x = 1500;
			rePortalTimer = 0;
			add(player);
			
			
			// artifact
			var sparkle:artifactSparkle = new artifactSparkle();
			sparkle.x = artifactOriginalPoint.x;
			sparkle.y = artifactOriginalPoint.y - 20;
			add(sparkle);
			
			artifact = new Artifact("SWORD",artifactOriginalPoint);
			add(artifact);
			
			FlxG.camera.setBounds(0, 0, map.width, map.height);
			FlxG.camera.follow(player, FlxCamera.STYLE_PLATFORMER);
			FlxG.worldBounds = new FlxRect(0, 0, map.width, map.height);
			
			
			
			//ui
			ui = new UI(player, enemyGroup);
			
			
			add(ui);
		}
		
		override public function update():void {
			
			FlxG.collide(enemyGroup, enemyGroup);
			
			FlxG.collide(player, map);
			//FlxG.collide(artifact, map);
			FlxG.collide(enemyGroup, map);
			FlxG.overlap(player, enemyGroup,onPlayerTouchesEnemy);
			
			FlxG.overlap(player, artifact,playerTouchesArtifact);
			FlxG.overlap(player, portal,playerTouchesPortal);
			
			rePortalTimer += FlxG.elapsed;
			if (!canHitPlayer) {
				enemyCanHitTimer += FlxG.elapsed;
				if (enemyCanHitTimer > .5) {
					canHitPlayer = true;
					enemyCanHitTimer = 0;
				}
			}
			
			super.update();
			
		}
		
		private function onPlayerTouchesEnemy(ob1:FlxObject,ob2:ProtoEnemy):void 
		{
			if (!canHitPlayer || !ob2.enraged || !ob2.alive)return;
			
			var enemyPn:Number = (ob2.x+ob2.width/2);
			var playerPn:Number = (player.x + player.width / 2);
			
			if (enemyPn > playerPn && player.facing == FlxObject.RIGHT) {
				player.hitPush(-1);
			}else if(enemyPn <= playerPn && player.facing == FlxObject.LEFT) {
				player.hitPush(1);
			}
			
			canHitPlayer = false;
		}
		
		private function playerTouchesPortal(ob1:FlxObject,ob2:FlxObject):void 
		{
			if (rePortalTimer < 1) return;
			FlxG.switchState(new HQState);
		}
		
		private function playerTouchesArtifact(ob1:FlxObject,ob2:FlxObject):void 
		{
			trace("playerTouchesArtifact");
			enemyGroup.callAll("enrage");
			artifact.kill();
			getArtifact();
			//alive 0 false
		}
		
		private function getArtifact():void 
		{
			if (gotArtifact) return;
			gotArtifact = true;
			//
			artifactWeapon = new ScottishClaymore(player);
			player.hasWeapon(artifactWeapon);
			artifactWeapon.enemies = enemyGroup;
			add(artifactWeapon);
			
			FlxG.shake(.03,.3);
		}
		
		/**
		 * HIT , FALL
		 * @param	reason
		 */
		public function playerIsDead(reason:String,throwDir:*=null):void 
		{
			
			if (reason == "HIT") {
				//trace("HIT");
				FlxG.switchState(new ScreenDieHit(player.getScreenXY(),throwDir));
			}else if (reason == "FALL") {
				//trace("FALL");
				FlxG.switchState(new ScreenDieHit(player.getScreenXY(),null,player.facing));
			}
		}
		
	}

}