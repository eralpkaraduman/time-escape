package actors 
{
	import org.flixel.FlxSprite;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class Portal extends FlxSprite 
	{
		
		[Embed(source='../maps/portalGFX.png')]private var gfx:Class;
		public var id:int;
		public function Portal(_x:Number,_y:Number) 
		{
			//makeGraphic(8, 8, 0xff0094FF);
			//acceleration.y = 1200;
			
			loadGraphic(gfx, true, false, 8, 8);
			this.x = _x;
			this.y = _y;
			addAnimation("whoom", [0, 1, 2, 1], 10, true);
			play("whoom");
		}
		
	}

}