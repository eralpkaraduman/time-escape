package actors 
{
	import flash.geom.Point;
	import org.flixel.FlxSprite;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class Artifact extends FlxSprite 
	{
		[Embed(source='../artifacts/sword.png')]private var SWORD:Class;
		private var gfx:Class;
		private var initPlace:Point;
		private var maxY:Number = 5;
		private var dir:int = -1;
		private var speed:Number = .1;
		/**
		 * SWORD , GUN
		 * @param	type
		 */
		public function Artifact(type:String,initPlace:Point) 
		{
			super();
			
			if (type == "SWORD") {
				initPlace.y -= 4;
				loadGraphic(SWORD, false, false);
			}
			
			this.initPlace = initPlace;
			this.x = initPlace.x;
			this.y = initPlace.y;
		}
		
		override public function update():void {
			
			var _ytarg:Number = this.y;
			_ytarg += (speed * dir);
			
			if (_ytarg <= initPlace.y - maxY) {
				dir = 1;
				//_ytarg = initPlace.y - maxY;
			}else if (_ytarg >= initPlace.y) {
				dir = -1;
				//_ytarg = initPlace.y;
			}
			
			y = _ytarg;
			
			super.update();
		}
		
	}

}