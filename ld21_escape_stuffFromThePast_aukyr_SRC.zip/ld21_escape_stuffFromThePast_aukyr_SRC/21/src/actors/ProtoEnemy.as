package actors 
{
	import flash.external.ExternalInterface;
	import flash.geom.Point;
	import org.flixel.FlxG;
	import org.flixel.FlxObject;
	import org.flixel.FlxSprite;
	import org.flixel.FlxU;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class ProtoEnemy extends FlxSprite 
	{
		private var _jump:Number;
		private var _jumpVelocity:Number = 600;
		private var walkingLeft:Boolean = false;
		private var walkingRight:Boolean = false;
		private var playerRef:*;
		private var mapRef:*;
		public var enraged:Boolean = false;
		private var wantsToJump:Boolean = false;
		private var jumpTimer:Number = 0;
		private var canJump:Boolean = false;
		private var stuckTimer:Number = 0;
		private var prevX:Number = -46869754;
		static private const JUMP_TIMER_LIMIT:Number = .60;
		static private const HIT_TIMER_LIMIT:Number = .2;
		private var initPos:Point = new Point();
		private var hitPushDir:int;
		
		[Embed(source='caveMen.png')]private var gfx:Class;
		private var _justHitTimer:Number = 437258734783463463;
		
		public function ProtoEnemy(_x:Number,_y:Number) 
		{
			super();
			
			health = 1;
			
			acceleration.y = 1200;
			maxVelocity.y = 120;
			maxVelocity.x = 50;
			/*
			acceleration.y = 1200;
			maxVelocity.y = 120;
			maxVelocity.x = 100;*/
			
			drag.x = maxVelocity.x * 3;
			
			//makeGraphic(8, 8, 0xffFF0000);
			
			loadGraphic(gfx, true, true);
			
			
			
			
			if (Math.round(Math.random()) == 1) {
				addAnimation("idle", [5,0], 4, true);
			}else {
				addAnimation("idle", [0,5], 4, true);
			}
			
			addAnimation("enraged", [2, 3], 4, true);
			addAnimation("dead", [4], 0, false);
			addAnimation("hit", [0,1], 15, true);
			
			play("idle");
			
			/*
			width = 6;
			height = 8;
			offset.x = 2;
			offset.y = 1;
			*/
			
			this.x = initPos.x = _x;
			this.y = initPos.y = _y;
			
			
		}
		
		override public function update():void {
			if (onScreen() && enraged && alive) {
				stepEnragedAI();
			}else {
				walkingLeft = false;
				walkingRight = false;
				wantsToJump = false;
			}
			
			
			if (wantsToJump) {
				jumpTimer += FlxG.elapsed;
				if (jumpTimer >= JUMP_TIMER_LIMIT) {
					canJump = true;
					jumpTimer = 0;
				}else {
					canJump = false;
				}
				
			}
			if(canJump){
				velocity.y = -_jumpVelocity;
				canJump = false;
			}
			
			wantsToJump = false;
			
			//left-right
			acceleration.x = 0;
			
			if (walkingLeft) {
				acceleration.x = drag.x;
				facing = RIGHT;
			}
			
			if (walkingRight) {
				acceleration.x = -drag.x;
				facing = LEFT;
			}
			
			//push - hit
			if (hitPushDir != 0) {
				
				velocity.y = -_jumpVelocity;
				velocity.x = hitPushDir * (_jumpVelocity);
				
				
				hitPushDir = 0;
			}
			
			// fall
			if (!mapRef) mapRef = FlxG.state["map"];
			if (y > mapRef.height*2) {
				//alive = false;
				kill();
			}
			
			_justHitTimer += FlxG.elapsed;
			
			
			if (!alive) {
				play("dead");
				alpha -= (FlxG.elapsed/5);
				
				if (alpha <= .1) {
					kill();
				}
				
			}else if (_justHitTimer >= HIT_TIMER_LIMIT) {
				_justHitTimer = HIT_TIMER_LIMIT * 2;
				if (enraged) {
					play("enraged");
				}else {
					play("idle");
					if (!playerRef) playerRef = FlxG.state["player"];
					if (this.x > playerRef.x) facing = LEFT;
					else if (this.x <= playerRef.x) facing = RIGHT;
				}
			}else {
				play("hit");
			}
			
			super.update();
		}
		
		public function hitPush(dir:int = 0,damage:Number = .25):void {
			if (!alive) return;
			if (_justHitTimer < HIT_TIMER_LIMIT) return;
			
			health -= damage;
			if (health <= 0) {
				alive = false;
				
				play("dead");
			}
			
			_justHitTimer = 0;
			this.hitPushDir = dir;
		}
		
		public function spawn(spawnPoint:Point):void 
		{
			x = spawnPoint.x;
			y = spawnPoint.y;
		}
		
		public function enrage():void {
			if (!alive) return;
			
			play("enraged");
			enraged = true;
		}
		
		private function stepEnragedAI():void 
		{
			if (!alive) return;
			if (!playerRef) playerRef = FlxG.state["player"];
			
			
			walkingLeft = false;
			walkingRight = false;
			
			// player is above
			if (playerRef.x > x) {
				walkingLeft = true;
			}else if(playerRef.x < x) {
				walkingRight = true;
			}
			
			if ((y - playerRef.y)>5) {
				wantsToJump = true;
			}
			
			// stuck behind wall?
			if (x == prevX) {
				stuckTimer += FlxG.elapsed;
				
				if (stuckTimer >= JUMP_TIMER_LIMIT) {
					wantsToJump = true;
					jumpTimer = JUMP_TIMER_LIMIT
					stuckTimer = 0;
				}
			}
			prevX = x;
			
			
		}
		
	}

}