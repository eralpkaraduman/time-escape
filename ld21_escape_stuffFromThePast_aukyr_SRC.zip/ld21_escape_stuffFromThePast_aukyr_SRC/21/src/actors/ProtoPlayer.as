package actors 
{
	import artifacts.ScottishClaymore;
	import flash.geom.Point;
	import org.flixel.FlxG;
	import org.flixel.FlxObject;
	import org.flixel.FlxSprite;
	import org.flixel.FlxU;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class ProtoPlayer extends FlxSprite 
	{
		private var _jump:Number;
		private var _jumpVelocity:Number = 50;
		private var weapon:ScottishClaymore;
		[Embed(source='internSprite.png')]private var gfx:Class;
		private var hitPushDir:int = 0;
		
		public function ProtoPlayer(X:Number=0, Y:Number=0) 
		{
			super(X, Y);
			
			health = 1;
			
			acceleration.y = 1200;
			maxVelocity.y = 120;
			maxVelocity.x = 100;
			drag.x = maxVelocity.x * 3;
			
			//makeGraphic(10, 10, 0xff0000FF);
			loadGraphic(gfx, true, true);
			addAnimation("idle",[1],0,false);
			addAnimation("idle_hasArtifact", [0], 0, false);
			addAnimation("dead", [2], 0, false);
			play("idle");
		}
		
		override public function update():void {
			
			//if (!alive) return;
			
			//jump
			if(alive){
				if((_jump >= 0) && (FlxG.keys.X))
				{
					_jump += FlxG.elapsed;
					if(_jump > 0.25)
						_jump = -1;
				}
				else
					_jump = -1;
				if(_jump > 0)
				{
					if(_jump < 0.065){
						velocity.y = -_jumpVelocity;
					}else
						velocity.y = -maxVelocity.y;
				}
				
				if (isTouching(DOWN)) {
					_jump = 0;
				}
				
				acceleration.x = 0;
				
				
				//left-right
				if (FlxG.keys.RIGHT && alive && onScreen()) {
					acceleration.x = drag.x;
					facing = RIGHT;
				}
				
				if (FlxG.keys.LEFT && alive && onScreen()) {
					acceleration.x = -drag.x;
					facing = LEFT;
				}
				
				//push - hit
				if (hitPushDir != 0) {
					
					velocity.y = -600;
					velocity.x = hitPushDir*600;
					
					hitPushDir = 0;
				}
				
				//fell off ?
				//if (y > FlxG.state["map"].height*1.5) {
				if (y > FlxG.state["map"].height) {
					alive = false;
					health = 0;
					FlxG.state["playerIsDead"]("FALL");
				}
				
				//shoot
				if (FlxG.keys.C) {
					if (weapon) weapon.shoot();
				}
			}
			
			/// anim ///
			if (!alive) {
				play("dead");
			}else if (weapon) {
				play("idle_hasArtifact");
			}else {
				play("idle");
			}
			
			super.update();
		}
		
		public function spawn(playerSpawnPoint:Point):void 
		{
			
			x = playerSpawnPoint.x;
			y = playerSpawnPoint.y;
		}
		
		public function hasWeapon(artifactWeapon:ScottishClaymore):void 
		{
			weapon = artifactWeapon;
		}
		
		public function hitPush(dir:int=0,damage:Number = .10):void 
		{
			if (!alive) return;
			
			if (damage >= health) {
				health = 0;
			}else {
				health -= damage;
			}
			
			if (health <= 0) {
				alive = false;
				health = 0;
				FlxG.state["playerIsDead"]("HIT",(dir>0)? RIGHT : LEFT);
			}
			
			if (health > 1) health = 1;
			
			
			this.hitPushDir = dir;
		}
		
	}

}