package artifacts 
{
	import actors.Portal;
	import actors.ProtoEnemy;
	import actors.ProtoPlayer;
	import flash.geom.Point;
	import org.flixel.FlxG;
	import org.flixel.FlxGroup;
	import org.flixel.FlxObject;
	import org.flixel.FlxSprite;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class ScottishClaymore extends FlxSprite 
	{
		public var enemies:FlxGroup;
		
		[Embed(source='swordSprite.png')]private var gfx:Class;
		private var shooting:Boolean = false;
		private var canShoot:Boolean = true;
		private var player:ProtoPlayer;
		private var rot:Number = 0;
		private var canShootTimer:Number = 0;
		public function ScottishClaymore(player:ProtoPlayer)
		{
			super();
			this.player = player;
			//offset.y = -10;
			rot = angle;
			
			//offset.y = 5;
			//centerOffsets(true);
			var fr:Number = 15;
			loadGraphic(gfx, true, true, 10, 15);
			addAnimation("swing", [0, 1, 2, 3,4],fr,false);
			addAnimation("ready",[4,0],fr,false);
			
			place();
			
			//loadRotatedGraphic(gfx, 32);
			addAnimationCallback(onAnim);
		}
		
		private function onAnim(name:String,frame:uint,i:uint):void 
		{
			if (name == "swing" && frame == 4) {
				//canShoot = true;
				canShoot = false;
				shooting = false;
				play("ready");
			}
		}
		
		public function shoot():void {
			if (canShoot) {
				shooting = true;
				canShoot = false;
				play("swing");
			}
		}
		
		override public function update():void {
			place();
			
			if (!canShoot && !shooting) {
				canShootTimer += FlxG.elapsed;
				if (canShootTimer>.2) {
					canShootTimer = 0;
					canShoot = true;
				}
			}
			
			if(shooting)FlxG.overlap(this, enemies,onHitEnemy);
			
			super.update();
			
			
		}
		
		private function onHitEnemy(ob1:FlxObject,ob2:ProtoEnemy):void 
		{
			var enemyPn:Number = (ob2.x+ob2.width/2);
			var playerPn:Number = (player.x+player.width/2);
			//ob2.kill();
			if (enemyPn > playerPn && player.facing == RIGHT) {
				ob2.hitPush(1);
			}else if(enemyPn <= playerPn && player.facing == LEFT) {
				ob2.hitPush(-1);
			}
		}
		
		private function place():void 
		{
			this.facing = (player.facing==LEFT)? RIGHT : LEFT;
			this.x = player.x + ((player.facing == LEFT)? -7 : 7);
			this.y = player.y + (-3);
			this.angle = (player.facing == LEFT)? -rot : rot;
		}
		
		
		
	}

}