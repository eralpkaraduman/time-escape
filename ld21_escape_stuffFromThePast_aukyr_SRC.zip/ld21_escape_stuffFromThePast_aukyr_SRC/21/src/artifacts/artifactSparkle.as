package artifacts 
{
	import org.flixel.FlxSprite;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class artifactSparkle extends FlxSprite 
	{
		[Embed(source='../actors/artifactSparkle.png')]private var gfx:Class;
		
		public function artifactSparkle() 
		{
			super();
			loadGraphic(gfx, true, false, 10, 30);
			addAnimation("sparkle", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 5, true);
			play("sparkle");
			
		}
		
	}

}