package ui 
{
	import actors.ProtoPlayer;
	import org.flixel.FlxG;
	import org.flixel.FlxGroup;
	import org.flixel.FlxSprite;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class UI extends FlxGroup 
	{
		private var player:ProtoPlayer;
		private var enemies:FlxGroup;
		
		private var healthBar_bg:FlxSprite;
		private var healthBar:FlxSprite;
		private var initBarW:Number;
		private var initBarX:Number;
		private var lastHealth:Number = -3573274;
		private var heart:FlxSprite;
		[Embed(source='heart.png')]private var heart_gfx:Class;
		private var beatTimer:Number = 0;
		private var panic:Boolean = false;
		private var drawP:Number = 1;
		static private const BAR_HEIGHT:Number = 2;
		
		public function UI(player:ProtoPlayer,enemies:FlxGroup) 
		{
			this.enemies = enemies;
			this.player = player;
			
			// player - healthbar
			healthBar_bg = new FlxSprite();
			var m:int = 3;
			healthBar_bg.x = m + 7;
			healthBar_bg.y = m+1;
			healthBar_bg.makeGraphic(FlxG.width-(m*2)-7, BAR_HEIGHT, 0x22FF0000);
			add(healthBar_bg);
			healthBar_bg.scrollFactor.x = 0;
			healthBar_bg.scrollFactor.y = 0;
			
			healthBar = new FlxSprite();
			healthBar.x = healthBar_bg.x;
			healthBar.y = healthBar_bg.y;
			add(healthBar);
			healthBar.scrollFactor.x = 0;
			healthBar.scrollFactor.y = 0;
			
			initBarW = healthBar_bg.width;
			initBarX = healthBar_bg.x;
			
			heart = new FlxSprite();
			heart.loadGraphic(heart_gfx, false, false);
			heart.x = 3; heart.y = 3;
			heart.scrollFactor.x = heart.scrollFactor.y = 0;
			add(heart);
		}
		
		override public function update():void {
			
			
			// draw healthbar
			//var drawP:Number = player.health;
			drawP += (player.health - drawP) / 15;
			drawP = drawP<0 ? 0 :drawP
			drawP = drawP>1 ? 1 :drawP
			
			if (lastHealth != player.health ) {
				
				if (player.alive) {
					try 
					{
						//healthBar.makeGraphic(initBarW * drawP, 4, 0x55FF0000);
						healthBar.makeGraphic(initBarW * drawP, BAR_HEIGHT, 0xffFF0000);
					} 
					catch (err:Error) 
					{
						trace("@UI::update", err);
					}
					healthBar.visible = true;
				}else {
					healthBar.visible = false;
				}
				
				lastHealth = drawP;
			}
			
			//health low alert
			if (drawP < .5) panic = true;
			
			beatTimer += FlxG.elapsed;
			if (panic) {
				
				if (beatTimer >= .2) {
					heart.visible = !heart.visible;
					beatTimer = 0;
				}
			}else {
				heart.visible = true;
			}
			
			
			
			super.update();
		}
		
	}

}