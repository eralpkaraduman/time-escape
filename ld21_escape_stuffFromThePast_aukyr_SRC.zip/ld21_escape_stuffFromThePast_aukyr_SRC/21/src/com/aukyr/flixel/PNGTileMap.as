package com.aukyr.flixel 
{
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.geom.Point;
	import flash.geom.Rectangle;
	
	
	public class PNGTileMap 
	{
		public static const OFFSET_TOP_LEFT:String = "OFFSET_TOP_LEFT";
		
		public static function parsePoints(pngFile:Class,colorKey:uint,levelSize:Point,offset:String = OFFSET_TOP_LEFT):Array {
			var layout:Bitmap = new pngFile();
			var bmpd:BitmapData =  layout.bitmapData;
			var mapTileSize:Point = new Point((levelSize.x / layout.width), (levelSize.y / layout.height));
			//trace("mapTileSize ", mapTileSize);
			var indexes_2d:Array = new Array();
			var w:uint = layout.width;
			var h:uint = layout.height;
			var r:uint;
			var c:uint;
			var p:uint;
			for(r = 0; r < h; r++){
				for(c = 0; c < w; c++)
				{
					p = bmpd.getPixel(c, r);
					if (p == colorKey) {
						
						var r_t:uint = r;
						var c_t:uint = c;
						if (offset == OFFSET_TOP_LEFT) {
							r_t = r_t * mapTileSize.y;
							c_t = c_t * mapTileSize.x;
						}
						
						indexes_2d.push(new Point(c_t,r_t ));
					}
				}
			}
			
			bmpd.dispose();
			return indexes_2d;
		}
		
		public static function parseIndexes(pngFile:Class, colorKey:uint, ifPush:*=1,elsePush:* = null):Array {
			var layout:Bitmap = new pngFile();
			var bmpd:BitmapData =  layout.bitmapData;
			
			var w:uint = layout.width;
			var h:uint = layout.height;
			var indexes_2d:Array = new Array();
			var r:uint;
			var c:uint;
			var p:uint;
			for(r = 0; r < h; r++){
				for(c = 0; c < w; c++)
				{
					p = bmpd.getPixel(c, r);
					if (p == colorKey) {
						indexes_2d.push(ifPush);
					}else {
						indexes_2d.push(elsePush);
					}
				}
			}
			
			bmpd.dispose();
			return indexes_2d;
		}
		
		static public function getRect(protoLevelMap:Class):Rectangle 
		{
			var layout:Bitmap = new protoLevelMap();
			var r:Rectangle = new Rectangle(0,0,layout.width,layout.height);
			layout.bitmapData.dispose();
			return r;
		}
		
	}

}