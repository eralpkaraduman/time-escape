package screens 
{
	import org.flixel.FlxG;
	import org.flixel.FlxState;
	import org.flixel.FlxText;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class WinState extends FlxState 
	{
		
		public function WinState() 
		{
			FlxG.bgColor = 0xffFFFFFF;
			
		}
		
		override public function create():void {
			var tx:String = "";
			tx += "!! YOU WON !!" + "\n"+"\n";
			tx += "Press X to go again!" + "\n";
			var text:FlxText = new FlxText(0, 0, FlxG.width, tx);
			text.color = 0xff000000;
			add(text);
			
			super.create();
		}
		
		override public function update():void {
			if (FlxG.keys.justReleased("X")) {
				FlxG.switchState(new IntroState());
			}
			
			super.update();
		}
		
	}

}