package screens 
{
	import levels.HQState;
	import org.flixel.FlxG;
	import org.flixel.FlxObject;
	import org.flixel.FlxState;
	import org.flixel.FlxText;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class IntroState extends FlxState 
	{
		private var text:FlxText;
		public var texts:Array;
		public var textsIndex:int = 0;
		
		public function IntroState() 
		{
		}
		
		override public function create():void {
			
			FlxG.bgColor = 0xff000000;
			
			var tx:String = "";
			var tx2:String = "";
			var tx3:String = "";
			var tx4:String = "";
			var tx5:String = "";
			var tx6:String = "";
			var tx7:String = "";
			
			tx += "LUDUM DARE 20 - ESCAPE COMPO GAME" + "\n";
			tx += "'STUFF FROM THE PAST' by Eralp Karaduman (AUKYR)" + "\n";
			tx += "Twitter: @aukyr" + "\n";
			tx += "\n";
			tx += "Press x to skip" + "\n";
			
			tx2 += "This game is about %60 complete, so let me tell you what it is about:" + "\n"+ "\n";
			tx2 += "This dude you are playing is responsible for adjustments made in time" + "\n"+ "\n";
			tx2 += "In a mission he had forgot claymore swords in the prehistoric era." + "\n";
			tx2 += "Balance of time was distrubed, and to fix this, he must find and remove the swords." + "\n";
			
			tx3 += "To travel back and forth in time, he uses portals" + "\n";
			tx3 += "Pass through 5 portals, and find the swords" + "\n"+"\n";
			tx3 += "(Every portal opents to the same place for now" + "\n";
			tx3 += "I will make 4 more levels tomorrow for the jam hopefuly)" + "\n";
			
			tx4 += "As you get the sword, prehistoric people will be angry" + "\n";
			tx4 += "They will attack you" + "\n";
			tx4 += "Because they believe that the sword is a gift from the gods" + "\n";
			tx4 += "And they don't want you to take it back" + "\n"+"\n";
			tx4 += "you must ESCAPE back to the portal" + "\n"+"\n";
			tx4 += "If you can get back and don't die" + "\n";
			tx4 += "YOU WIN" + "\n";
			
			tx5 += "GOOD LUCK!" + "\n";
			tx5 += "It's sad I could not finish this game for the compo" + "\n";
			tx5 += "This is my first real attempt on compo, worked hard on it" + "\n";
			tx5 += "So I'm submitting anyway... ENJOY" + "\n"+ "\n";
			tx5 += "Now, I must sleep.. work tomorrow" + "\n";
			
			tx6 += "Oh, I almost forgot.." + "\n"+ "\n";
			tx6 += "Arrow keys : MOVE" + "\n";
			tx6 += "X : JUMP" + "\n";
			tx6 += "C : ATTACK (When you have the sword)" + "\n";
			
			tx7 += ": )" + "\n";
			
			
			texts = [tx, tx2,tx3,tx4,tx5,tx6,tx7];
			skip();
			
			super.create();
		}
		
		override public function update():void {
			if (FlxG.keys.justReleased("X")) {
				skip();
			}
			
			super.update();
		}
		
		
		
		private function skip():void 
		{
			if (textsIndex >= texts.length) {
				FlxG.switchState(new HQState());
			}
			
			if(text)text.kill();
			text = new FlxText(0, 0, FlxG.width, texts[textsIndex]);
			add(text);
			textsIndex++;
		}
		
	}

}