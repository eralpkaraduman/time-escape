package screens 
{
	import actors.ProtoPlayer;
	import com.aukyr.flixel.PNGTileMap;
	import flash.geom.Point;
	import levels.HQState;
	import levels.ProtoState;
	import org.flixel.FlxBasic;
	import org.flixel.FlxCamera;
	import org.flixel.FlxEmitter;
	import org.flixel.FlxG;
	import org.flixel.FlxGroup;
	import org.flixel.FlxObject;
	import org.flixel.FlxParticle;
	import org.flixel.FlxPoint;
	import org.flixel.FlxRect;
	import org.flixel.FlxSprite;
	import org.flixel.FlxState;
	import org.flixel.FlxText;
	import org.flixel.FlxTilemap;
	
	/**
	$(CBI)* ...
	$(CBI)* @author Aukyr
	$(CBI)*/
	public class ScreenDieHit extends FlxState 
	{
		private var playerScreenXY:FlxPoint;
		[Embed(source='dieScreenMap.png')]private var dieScreenMap:Class;
		[Embed(source = '../maps/protoTiles.png')]private var protoTiles:Class;
		private var player:ProtoPlayer;
		private var throwTo:*;
		private var f:Number = 150;
		private var force:Point = new Point(f,f);
		private var fall:Boolean = false;
		static private const TIME_SCALE:Number = .3;
		private var checkFirstHitDone:Boolean = false;
		public var map:FlxTilemap;
		private var _facing:*;
		
		private var bloodEmitter:FlxEmitter;
		private var bloodEmitterParticleCount:Number;
		private var skull:FlxSprite;
		[Embed(source='skull.png')]private var skull_gfx:Class;
		private var text:FlxText;
		
		public function ScreenDieHit(playerScreenXY:FlxPoint,throwTo:*=null,facing:*=null) 
		{
			ProtoState.gotArtifact = false;
			
			this._facing = facing;
			this.throwTo = throwTo;
			this.playerScreenXY = playerScreenXY;
			if (throwTo == null) fall = true;
		}
		
		override public function create():void {
			
			text = new FlxText(0, 0, 300, "     YOU DIED IN A TIME WHICH WAS NOT YOURS\nYOUR CORPSE WILL ROT BEFORE YOU WILL BE BORN\n                          X TO TRY AGAIN");
			text.alignment = "left";
			text.visible = false;
			add(text);
			
			skull = new FlxSprite();
			skull.loadGraphic(skull_gfx);
			add(skull);
			
			map = new FlxTilemap();
			map.loadMap(FlxTilemap.imageToCSV(dieScreenMap), protoTiles);
			
			if(!fall)FlxG.timeScale = TIME_SCALE;
			FlxG.bgColor = 0xffa69a90;
			
			if (fall) playerScreenXY.y = 0;
			playerScreenXY.y += (map.height -FlxG.height);
			
			skull.y = (map.height -FlxG.height)+65;
			skull.x = 105;
			skull.scale = new FlxPoint(3, 3);
			skull.alpha = 0;
			
			text.x = -3;
			text.y = (map.height -FlxG.height);
			//skull.scrollFactor.x = 0;
			//skull.scrollFactor.y = 0;
			
			player = new ProtoPlayer(playerScreenXY.x,playerScreenXY.y);
			player.maxVelocity.y = 300;
			if(!fall)player.maxVelocity.x = 300;
			if(!fall)player.velocity.x = (throwTo == FlxObject.LEFT)? -force.x : force.x;
			player.facing = throwTo;
			if(!fall)player.velocity.y = -force.y;
			player.alive = false;
			
			if (fall) player.facing = _facing;
			
			add(player);
			
			// emiiter
			bloodEmitterParticleCount = 25;
			bloodEmitter = new FlxEmitter(0,0,bloodEmitterParticleCount);
			
			
			add(map);
			map.visible = false;
			
			FlxG.camera.setBounds(0, 0, map.width, map.height);
			FlxG.camera.follow(player, FlxCamera.STYLE_PLATFORMER);
			FlxG.worldBounds = new FlxRect(0, 0, map.width, map.height);
			
			if(!fall)emitBlood();
		}
		
		override public function update():void {
			
			if (skull.alpha>.5 && (FlxG.keys.X || FlxG.keys.C || FlxG.keys.UP || FlxG.keys.LEFT || FlxG.keys.RIGHT || FlxG.keys.DOWN)) {
				FlxG.switchState(new HQState());
			}
			
			if(skull.alpha!=1)skull.alpha += (FlxG.elapsed)/2;
			if (skull.alpha > .4) text.visible = true;
			
			bloodEmitter.x = player.x + (player.facing==FlxObject.RIGHT ? 7 : 3);
			bloodEmitter.y = player.y + (fall ? 6 : 6);
			
			
			
			FlxG.collide(player, map);
			
			
			
			if (force.y > .2) 
			{
				
				if (player.isTouching(FlxObject.LEFT)) {
					player.velocity.x = force.x;
					player.facing = FlxObject.RIGHT;
					
					force.x = force.x / 2;
				}
				
				if (player.isTouching(FlxObject.RIGHT)) {
					player.velocity.x = -force.x;
					player.facing = FlxObject.LEFT;
					
					force.x = force.x / 2;
					
					checkFirstHit();
				}
				
				if (player.isTouching(FlxObject.DOWN)) {
					player.velocity.y = -force.y;
					player.velocity.x = (player.facing == FlxObject.LEFT)? -force.x : force.x;
					
					force.x = force.x / 2;
					force.y = force.y / 2;
					
					checkFirstHit();
				}
				
				if (player.isTouching(FlxObject.UP)) {
					player.velocity.y = +force.y;
					player.velocity.x = (player.facing == FlxObject.LEFT)? -force.x : force.x;
					
					force.x = force.x / 2;
					force.y = force.y / 2;
					
					checkFirstHit();
				}
			}
			
			super.update();
		}
		
		private function checkFirstHit():void 
		{
			if (checkFirstHitDone) return;
			checkFirstHitDone = true;
			
			if (fall) {
				FlxG.timeScale = TIME_SCALE;
				emitBlood();
			}
			
			
		}
		
		private function emitBlood():void 
		{
			//
			bloodEmitter.gravity = 300;
			bloodEmitter.maxRotation = 0;
			bloodEmitter.minRotation = 0;
			var s:Number = 50;
			
			bloodEmitter.setYSpeed(-s, 0);
			if (player.facing == FlxObject.LEFT) {
				bloodEmitter.setXSpeed( 0, s);
			}else {
				bloodEmitter.setXSpeed( -s, 0);
			}
			//
			for (var i:int = 0; i < bloodEmitterParticleCount; i++) 
			{
				var blood:FlxParticle = new FlxParticle();
				blood.makeGraphic(1, 1, 0xffFF0000);
				blood.exists = false;
				bloodEmitter.add(blood);
			}
			add(bloodEmitter);
			
			bloodEmitter.start(false,0,0.008);
		}
		
	}

}