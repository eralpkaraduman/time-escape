package 
{
	import flash.display.Sprite;
	import flash.events.Event;
	import levels.HQState;
	import levels.ProtoState;
	import org.flixel.FlxG;
	import org.flixel.FlxGame;
	import screens.IntroState;
	
	[SWF(width = "480", height = "320", backgroundColor = "0x000000")]
	[Frame(factoryClass="Preloader")]
	public class Main extends FlxGame 
	{
		static public var skyColor:Number = 0xff71b0d0;
		
		public function Main():void 
		{
			super(240, 160, IntroState, 2);
			//super(240, 160, HQState, 2);
			//super(240, 160, ProtoState, 2);
		}
		
	}
	
}